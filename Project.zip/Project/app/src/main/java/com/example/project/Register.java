package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity {

    EditText name,email,phone,pass,re_pass;
    Spinner dept;
    Button reg;
    ProgressBar loading;
    String nama,mail,phoneNo,password,repassword,department;
    private FirebaseAuth mAuth;
    DatabaseReference reff;
    Edir edir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name=findViewById(R.id.etName);
        email=findViewById(R.id.etEmail);
        phone=findViewById(R.id.etPhone);
        pass=findViewById(R.id.etEnterPass);
        re_pass=findViewById(R.id.etReEnterPass);
        dept=findViewById(R.id.spDept);

        //ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,jabatan);
        //dept.setAdapter(arrayAdapter);
        reg=findViewById(R.id.btnReg);
        loading=findViewById(R.id.pbLoading);
        edir=new Edir();
        mAuth=FirebaseAuth.getInstance();
        reff = FirebaseDatabase.getInstance().getReference("EDir");


        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loading.setVisibility(View.VISIBLE);
                nama = name.getText().toString().trim();
                mail = email.getText().toString().trim();
                phoneNo = phone.getText().toString().trim();
                password = pass.getText().toString().trim();
                repassword = re_pass.getText().toString().trim();
                department = dept.getSelectedItem().toString();


                // checking if the password and confirm password is equal or not.
                if (!password.equals(repassword)) {
                    Toast.makeText(Register.this, "Please make sure that password is same..", Toast.LENGTH_LONG).show();
                } else if (TextUtils.isEmpty(nama) && TextUtils.isEmpty(mail) && TextUtils.isEmpty(phoneNo) && TextUtils.isEmpty(password) && TextUtils.isEmpty(repassword)) {

                    // checking if the text fields are empty or not.
                    Toast.makeText(Register.this, "Please enter your credentials..", Toast.LENGTH_LONG).show();
                } else {

                    // on below line we are creating a new user by passing email and password.
                    mAuth.createUserWithEmailAndPassword(mail, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            // on below line we are checking if the task is success or not.
                            if (task.isSuccessful()) {

                                // in on success method we are hiding our progress bar and opening a login activity.
                                loading.setVisibility(View.GONE);
                                Toast.makeText(Register.this, "User Registered..", Toast.LENGTH_SHORT).show();
                                //add data to firebase
                                //add data to firebase
                                addDatatoFirebase(nama, mail,phoneNo,department);
                                Intent i = new Intent(Register.this, MainActivity.class);
                                startActivity(i);
                                finish();
                            } else {

                                // in else condition we are displaying a failure toast message.
                                loading.setVisibility(View.GONE);
                                Toast.makeText(Register.this, "Fail to register user..", Toast.LENGTH_SHORT).show();
                            }
                        }

                    });
                }
            }
        });
    }
    private void addDatatoFirebase(String nama,String mail,String phoneNo,String department){
        edir.setNama(nama);
        edir.setMail(mail);
        edir.setPhoneNo(phoneNo);
        edir.setDepartment(department);

        // we are use add value event listener method
        // which is called with database reference.
        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // inside the method of on Data change we are setting
                // our object class to our database reference.
                // data base reference will sends data to firebase.
                reff.child(phoneNo).setValue(edir);
                //reff.setValue(edir);

                // after adding this data we are showing toast message.
                Toast.makeText(Register.this, "Directory added", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.
                Toast.makeText(Register.this, "Fail to add directory " + error, Toast.LENGTH_LONG).show();
            }
        });

    }
}